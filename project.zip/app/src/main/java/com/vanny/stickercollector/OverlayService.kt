package com.vanny.stickercollector

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val bgThread = HandlerThread("capture").also { it.start() }
    private val bg = Handler(bgThread.looper)

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private val lock = Any()
    private var lastImage: Image? = null

    private var fab: View? = null
    private var fabParams: WindowManager.LayoutParams? = null
    private var selector: SelectorView? = null

    private var sw = 0
    private var sh = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_NOT_STICKY
        startFg()

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java)
        else
            @Suppress("DEPRECATION") intent?.getParcelableExtra("data")

        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSelf()
                }
            }, main)
        }

        setupCapture()
        showFab()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("stk", "Sticker Collector", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "stk")
            .setContentTitle("Sticker Collector is running")
            .setContentText("Use the floating button over TikTok")
            .setSmallIcon(android.R.drawable.ic_menu_crop)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    @Suppress("DEPRECATION")
    private fun setupCapture() {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels
        sh = dm.heightPixels

        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 3)
        reader = r
        vd = projection!!.createVirtualDisplay(
            "stk", sw, sh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, bg
        )
        r.setOnImageAvailableListener({ ir ->
            val img = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
            synchronized(lock) {
                lastImage?.close()
                lastImage = img
            }
        }, bg)
    }

    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun showFab() {
        val size = (56 * resources.displayMetrics.density).toInt()
        val v = TextView(this).apply {
            text = "✂"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(220, 255, 64, 129))
            }
        }
        val p = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = sw - size - 16
            y = sh / 3
        }
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = p.x; startY = p.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - downX).toInt()
                    val my = (e.rawY - downY).toInt()
                    if (abs(mx) > 12 || abs(my) > 12) moved = true
                    if (moved) {
                        p.x = startX + mx
                        p.y = startY + my
                        wm.updateViewLayout(view, p)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) startSelect()
            }
            true
        }
        fab = v
        fabParams = p
        wm.addView(v, p)
    }

    private fun startSelect() {
        if (selector != null) return
        fab?.visibility = View.GONE
        val sel = SelectorView(this) { rect -> finishSelect(rect) }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        selector = sel
        wm.addView(sel, p)
    }

    private fun finishSelect(rect: Rect?) {
        selector?.let { wm.removeView(it) }
        selector = null
        if (rect == null) {
            fab?.visibility = View.VISIBLE
            return
        }
        // wait for the screen to redraw without the overlay, then grab the latest frame
        main.postDelayed({
            bg.post { grabAndSave(rect) }
            main.postDelayed({ fab?.visibility = View.VISIBLE }, 300)
        }, 350)
    }

    private fun grabAndSave(rect: Rect) {
        val img: Image
        synchronized(lock) {
            img = lastImage ?: run {
                toast("No frame yet, try again")
                return
            }
            try {
                saveCrop(img, rect)
            } catch (t: Throwable) {
                toast("Save failed: ${t.message}")
            }
        }
    }

    private fun saveCrop(img: Image, rect: Rect) {
        val plane = img.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * img.width
        val full = Bitmap.createBitmap(
            img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888
        )
        full.copyPixelsFromBuffer(plane.buffer)

        val l = rect.left.coerceIn(0, img.width - 2)
        val t = rect.top.coerceIn(0, img.height - 2)
        val r = rect.right.coerceIn(l + 1, img.width)
        val b = rect.bottom.coerceIn(t + 1, img.height)
        val crop = Bitmap.createBitmap(full, l, t, r - l, b - t)

        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "sticker_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(
                MediaStore.Images.Media.RELATIVE_PATH,
                Environment.DIRECTORY_PICTURES + "/StickerCollector"
            )
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        if (uri == null) {
            toast("Could not create file")
            return
        }
        contentResolver.openOutputStream(uri)?.use {
            crop.compress(Bitmap.CompressFormat.PNG, 100, it)
        }
        toast("Saved ${r - l}x${b - t} to Pictures/StickerCollector")
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }

    override fun onDestroy() {
        fab?.let { runCatching { wm.removeView(it) } }
        selector?.let { runCatching { wm.removeView(it) } }
        synchronized(lock) {
            lastImage?.close()
            lastImage = null
        }
        vd?.release()
        reader?.close()
        projection?.stop()
        bgThread.quitSafely()
        super.onDestroy()
    }
}
