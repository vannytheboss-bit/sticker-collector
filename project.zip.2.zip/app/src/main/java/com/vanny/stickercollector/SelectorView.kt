package com.vanny.stickercollector

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View

class SelectorView(
    context: Context,
    private val onDone: (Rect?) -> Unit
) : View(context) {

    private val dim = Paint().apply { color = Color.argb(140, 0, 0, 0) }
    private val border = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val hint = Paint().apply {
        color = Color.WHITE
        textSize = 48f
    }

    private var sx = 0f
    private var sy = 0f
    private var ex = 0f
    private var ey = 0f
    private var dragging = false

    private fun sel(): Rect = Rect(
        minOf(sx, ex).toInt(), minOf(sy, ey).toInt(),
        maxOf(sx, ex).toInt(), maxOf(sy, ey).toInt()
    )

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (!dragging) {
            c.drawRect(0f, 0f, w, h, dim)
            c.drawText("Drag a box around the sticker", 40f, h / 2, hint)
            return
        }
        val r = sel()
        c.drawRect(0f, 0f, w, r.top.toFloat(), dim)
        c.drawRect(0f, r.bottom.toFloat(), w, h, dim)
        c.drawRect(0f, r.top.toFloat(), r.left.toFloat(), r.bottom.toFloat(), dim)
        c.drawRect(r.right.toFloat(), r.top.toFloat(), w, r.bottom.toFloat(), dim)
        c.drawRect(r, border)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                sx = e.x; sy = e.y; ex = e.x; ey = e.y
                dragging = true
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                ex = e.x; ey = e.y
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                ex = e.x; ey = e.y
                val r = sel()
                onDone(if (r.width() > 40 && r.height() > 40) r else null)
            }
            MotionEvent.ACTION_CANCEL -> onDone(null)
        }
        return true
    }
}
