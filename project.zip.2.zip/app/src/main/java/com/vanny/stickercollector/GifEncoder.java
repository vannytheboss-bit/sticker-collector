package com.vanny.stickercollector;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/** Pure-Java animated GIF encoder. Frames are ARGB int arrays (alpha ignored). */
public class GifEncoder {

    public static void encode(List<int[]> frames, int w, int h,
                              List<Integer> delaysCs, OutputStream out) throws IOException {
        int[] palette = buildPalette(frames);
        int[] lut = new int[32768];
        Arrays.fill(lut, -1);

        writeStr(out, "GIF89a");
        writeShort(out, w);
        writeShort(out, h);
        out.write(0xF7);
        out.write(0);
        out.write(0);
        for (int i = 0; i < 256; i++) {
            int c = palette[i];
            out.write((c >> 16) & 255);
            out.write((c >> 8) & 255);
            out.write(c & 255);
        }
        // loop forever
        out.write(0x21);
        out.write(0xFF);
        out.write(11);
        writeStr(out, "NETSCAPE2.0");
        out.write(3);
        out.write(1);
        writeShort(out, 0);
        out.write(0);

        Lzw lzw = new Lzw();
        byte[] idx = new byte[w * h];
        for (int f = 0; f < frames.size(); f++) {
            int[] px = frames.get(f);
            for (int i = 0; i < idx.length; i++) {
                int c = px[i];
                int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                int key = ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3);
                int p = lut[key];
                if (p < 0) {
                    p = nearest(palette, (r & 0xF8) | 4, (g & 0xF8) | 4, (b & 0xF8) | 4);
                    lut[key] = p;
                }
                idx[i] = (byte) p;
            }
            out.write(0x21);
            out.write(0xF9);
            out.write(4);
            out.write(0x04);
            writeShort(out, Math.max(2, delaysCs.get(f)));
            out.write(0);
            out.write(0);

            out.write(0x2C);
            writeShort(out, 0);
            writeShort(out, 0);
            writeShort(out, w);
            writeShort(out, h);
            out.write(0);
            lzw.encode(out, idx);
        }
        out.write(0x3B);
        out.flush();
    }

    private static int nearest(int[] pal, int r, int g, int b) {
        int best = 0, bd = Integer.MAX_VALUE;
        for (int i = 0; i < 256; i++) {
            int c = pal[i];
            int dr = ((c >> 16) & 255) - r, dg = ((c >> 8) & 255) - g, db = (c & 255) - b;
            int d = dr * dr + dg * dg + db * db;
            if (d < bd) {
                bd = d;
                best = i;
            }
        }
        return best;
    }

    private static void writeStr(OutputStream o, String s) throws IOException {
        for (int i = 0; i < s.length(); i++) o.write(s.charAt(i));
    }

    private static void writeShort(OutputStream o, int v) throws IOException {
        o.write(v & 255);
        o.write((v >> 8) & 255);
    }

    // ---- median-cut palette (256 colours, shared by all frames) ----
    private static int[] buildPalette(List<int[]> frames) {
        int total = 0;
        for (int[] f : frames) total += f.length;
        int step = Math.max(1, total / 40000);
        ArrayList<Integer> samples = new ArrayList<>();
        int n = 0;
        for (int[] f : frames) {
            for (int i = 0; i < f.length; i++, n++) {
                if (n % step == 0) samples.add(f[i] & 0xFFFFFF);
            }
        }
        ArrayList<List<Integer>> boxes = new ArrayList<>();
        boxes.add(samples);
        while (boxes.size() < 256) {
            int pick = -1, pickRange = 0;
            for (int i = 0; i < boxes.size(); i++) {
                List<Integer> bx = boxes.get(i);
                if (bx.size() < 2) continue;
                int range = maxRange(bx);
                if (range > pickRange) {
                    pickRange = range;
                    pick = i;
                }
            }
            if (pick < 0 || pickRange == 0) break;
            List<Integer> bx = boxes.remove(pick);
            final int shift = widestChannelShift(bx);
            Collections_sort(bx, shift);
            int mid = bx.size() / 2;
            boxes.add(new ArrayList<>(bx.subList(0, mid)));
            boxes.add(new ArrayList<>(bx.subList(mid, bx.size())));
        }
        int[] pal = new int[256];
        for (int i = 0; i < boxes.size() && i < 256; i++) {
            List<Integer> bx = boxes.get(i);
            long r = 0, g = 0, b = 0;
            for (int c : bx) {
                r += (c >> 16) & 255;
                g += (c >> 8) & 255;
                b += c & 255;
            }
            int cnt = Math.max(1, bx.size());
            pal[i] = (int) (r / cnt) << 16 | (int) (g / cnt) << 8 | (int) (b / cnt);
        }
        return pal;
    }

    private static void Collections_sort(List<Integer> l, final int shift) {
        l.sort(new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return Integer.compare((a >> shift) & 255, (b >> shift) & 255);
            }
        });
    }

    private static int maxRange(List<Integer> bx) {
        int[] mn = {255, 255, 255}, mx = {0, 0, 0};
        for (int c : bx) {
            int[] v = {(c >> 16) & 255, (c >> 8) & 255, c & 255};
            for (int k = 0; k < 3; k++) {
                if (v[k] < mn[k]) mn[k] = v[k];
                if (v[k] > mx[k]) mx[k] = v[k];
            }
        }
        return Math.max(mx[0] - mn[0], Math.max(mx[1] - mn[1], mx[2] - mn[2]));
    }

    private static int widestChannelShift(List<Integer> bx) {
        int[] mn = {255, 255, 255}, mx = {0, 0, 0};
        for (int c : bx) {
            int[] v = {(c >> 16) & 255, (c >> 8) & 255, c & 255};
            for (int k = 0; k < 3; k++) {
                if (v[k] < mn[k]) mn[k] = v[k];
                if (v[k] > mx[k]) mx[k] = v[k];
            }
        }
        int r = mx[0] - mn[0], g = mx[1] - mn[1], b = mx[2] - mn[2];
        if (r >= g && r >= b) return 16;
        if (g >= b) return 8;
        return 0;
    }

    // ---- GIF LZW with 8-bit min code size ----
    private static class Lzw {
        final int[] codes = new int[1 << 20];
        final int[] stamp = new int[1 << 20];
        int ver = 0;
        // bit packer
        final byte[] block = new byte[255];
        int blockLen = 0;
        int cur = 0, curBits = 0;
        OutputStream os;

        void emit(int code, int size) throws IOException {
            cur |= code << curBits;
            curBits += size;
            while (curBits >= 8) {
                putByte(cur & 255);
                cur >>>= 8;
                curBits -= 8;
            }
        }

        void putByte(int b) throws IOException {
            block[blockLen++] = (byte) b;
            if (blockLen == 255) flushBlock();
        }

        void flushBlock() throws IOException {
            if (blockLen > 0) {
                os.write(blockLen);
                os.write(block, 0, blockLen);
                blockLen = 0;
            }
        }

        void encode(OutputStream out, byte[] pix) throws IOException {
            os = out;
            blockLen = 0;
            cur = 0;
            curBits = 0;
            final int minSize = 8;
            final int clear = 1 << minSize;
            final int eoi = clear + 1;
            out.write(minSize);
            int codeSize = minSize + 1;
            int next = eoi + 1;
            ver++;
            emit(clear, codeSize);
            int prefix = pix[0] & 255;
            for (int i = 1; i < pix.length; i++) {
                int b = pix[i] & 255;
                int key = (prefix << 8) | b;
                if (stamp[key] == ver) {
                    prefix = codes[key];
                    continue;
                }
                emit(prefix, codeSize);
                if (next >= (1 << codeSize) && codeSize < 12) codeSize++;
                if (next < 4096) {
                    codes[key] = next++;
                    stamp[key] = ver;
                } else {
                    emit(clear, codeSize);
                    codeSize = minSize + 1;
                    next = eoi + 1;
                    ver++;
                }
                prefix = b;
            }
            emit(prefix, codeSize);
            if (next >= (1 << codeSize) && codeSize < 12) codeSize++;
            emit(eoi, codeSize);
            if (curBits > 0) {
                putByte(cur & 255);
                cur = 0;
                curBits = 0;
            }
            flushBlock();
            out.write(0);
        }
    }
}
