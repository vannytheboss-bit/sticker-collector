package com.vanny.stickercollector

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class OverlayService : Service() {

    companion object {
        const val MAX_MS = 8000L          // hard limit for one clip
        const val STILL_MS = 2000L        // no movement for this long = still sticker
        const val MIN_FRAME_GAP_MS = 66L  // ~15 fps max
        const val MAX_SIDE = 360f         // longest side of the saved clip
        const val SIG = 32                // loop detector samples a 32x32 grid
        const val CELL_DIFF = 24          // gray difference that counts as "changed"
        const val MOVED_CELLS = 10        // cells changed = the sticker has started moving
        const val RETURN_CELLS = 2        // cells changed or fewer = back at the first frame
        const val MIN_MOVED_FRAMES = 5    // frames after moving before a loop can end
    }

    private enum class Reason { LOOP, MANUAL, TIMEOUT, STILL }

    /** One recording in progress. */
    private class Rec(val l: Int, val t: Int, val cw: Int, val ch: Int, val ow: Int, val oh: Int) {
        val frames = ArrayList<IntArray>()
        val times = ArrayList<Long>()
        var firstSig: IntArray? = null
        var firstFull: Bitmap? = null
        @Volatile var movedAway = false
        var movedFrames = 0
        var endTime = 0L
        @Volatile var done = false
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val bgThread = HandlerThread("capture").also { it.start() }
    private val bg = Handler(bgThread.looper)

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null

    private val lock = Any()
    private var lastImage: Image? = null

    @Volatile private var rec: Rec? = null
    private var frameBmp: Bitmap? = null

    private var fab: View? = null
    private var selector: SelectorView? = null
    private var stopBtn: View? = null

    private var sw = 0
    private var sh = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_NOT_STICKY
        startFg()

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java)
        else
            @Suppress("DEPRECATION") intent?.getParcelableExtra("data")

        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSelf()
                }
            }, main)
        }

        setupCapture()
        showFab()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("stk", "Sticker Collector", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "stk")
            .setContentTitle("Sticker Collector is running")
            .setContentText("Use the floating button over TikTok")
            .setSmallIcon(android.R.drawable.ic_menu_crop)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    @Suppress("DEPRECATION")
    private fun setupCapture() {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels
        sh = dm.heightPixels

        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 3)
        reader = r
        vd = projection!!.createVirtualDisplay(
            "stk", sw, sh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, bg
        )
        // keep the newest frame open so a still screen can still be captured
        r.setOnImageAvailableListener({ ir ->
            val img = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
            synchronized(lock) {
                lastImage?.close()
                lastImage = img
            }
            val st = rec
            if (st != null && !st.done) {
                try {
                    addFrame(img, st)
                } catch (_: Throwable) {
                    // skip a bad frame
                }
            }
        }, bg)
    }

    /** Background thread. Handles one screen frame while recording. */
    private fun addFrame(img: Image, st: Rec) {
        val now = SystemClock.uptimeMillis()
        if (st.times.isNotEmpty() && now - st.times.last() < MIN_FRAME_GAP_MS) return

        val plane = img.planes[0]
        val ps = plane.pixelStride
        val bw = plane.rowStride / ps
        var fb = frameBmp
        if (fb == null || fb.width != bw || fb.height != img.height) {
            fb = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
            frameBmp = fb
        }
        plane.buffer.rewind()
        fb.copyPixelsFromBuffer(plane.buffer)

        val crop = Bitmap.createBitmap(fb, st.l, st.t, st.cw, st.ch)
        val px = IntArray(st.ow * st.oh)
        if (st.ow == st.cw && st.oh == st.ch) {
            crop.getPixels(px, 0, st.ow, 0, 0, st.ow, st.oh)
        } else {
            val s = Bitmap.createScaledBitmap(crop, st.ow, st.oh, true)
            s.getPixels(px, 0, st.ow, 0, 0, st.ow, st.oh)
            if (s !== crop) s.recycle()
        }
        if (st.firstFull == null) {
            st.firstFull = if (crop === fb) fb.copy(Bitmap.Config.ARGB_8888, false) else crop
        } else if (crop !== fb) {
            crop.recycle()
        }

        val sig = signature(px, st.ow, st.oh)
        val first = st.firstSig
        if (first == null) {
            st.firstSig = sig
        } else {
            val changed = countChanged(first, sig)
            if (!st.movedAway) {
                if (changed >= MOVED_CELLS) {
                    st.movedAway = true
                    st.movedFrames = 0
                }
            } else {
                st.movedFrames++
                if (changed <= RETURN_CELLS && st.movedFrames >= MIN_MOVED_FRAMES) {
                    // back at the first frame: the loop is complete, drop this duplicate frame
                    st.endTime = now
                    finish(st, Reason.LOOP)
                    return
                }
            }
        }

        st.frames.add(px)
        st.times.add(now)
    }

    private fun signature(px: IntArray, w: Int, h: Int): IntArray {
        val s = IntArray(SIG * SIG)
        for (gy in 0 until SIG) {
            val y = gy * h / SIG
            for (gx in 0 until SIG) {
                val x = gx * w / SIG
                val c = px[y * w + x]
                val r = (c shr 16) and 255
                val g = (c shr 8) and 255
                val b = c and 255
                s[gy * SIG + gx] = (r * 30 + g * 59 + b * 11) / 100
            }
        }
        return s
    }

    private fun countChanged(a: IntArray, b: IntArray): Int {
        var n = 0
        for (i in a.indices) if (abs(a[i] - b[i]) > CELL_DIFF) n++
        return n
    }

    // ---------- floating buttons ----------

    private fun showFab() {
        val size = (56 * resources.displayMetrics.density).toInt()
        val v = TextView(this).apply {
            text = "✂"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(220, 255, 64, 129))
            }
        }
        val p = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = sw - size - 16
            y = sh / 3
        }
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = p.x; startY = p.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - downX).toInt()
                    val my = (e.rawY - downY).toInt()
                    if (abs(mx) > 12 || abs(my) > 12) moved = true
                    if (moved) {
                        p.x = startX + mx
                        p.y = startY + my
                        wm.updateViewLayout(view, p)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) startSelect()
            }
            true
        }
        fab = v
        wm.addView(v, p)
    }

    /** Main thread. Red STOP button placed outside the box so it is not recorded. */
    private fun showStop(box: Rect, st: Rec) {
        val d = resources.displayMetrics.density
        val bw = (88 * d).toInt()
        val bh = (44 * d).toInt()
        val margin = (8 * d).toInt()
        val x = (box.centerX() - bw / 2).coerceIn(0, max(0, sw - bw))
        val y = when {
            box.top - bh - margin >= 0 -> box.top - bh - margin
            box.bottom + margin + bh <= sh -> box.bottom + margin
            else -> 0
        }
        val v = TextView(this).apply {
            text = "■ STOP"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                cornerRadius = 24 * d
                setColor(Color.argb(230, 220, 38, 38))
            }
            setOnClickListener { bg.post { finish(st, Reason.MANUAL) } }
        }
        val p = WindowManager.LayoutParams(
            bw, bh, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        stopBtn = v
        wm.addView(v, p)
    }

    private fun removeStop() {
        stopBtn?.let { runCatching { wm.removeView(it) } }
        stopBtn = null
    }

    // ---------- selection and recording flow ----------

    private fun startSelect() {
        if (selector != null || rec != null) return
        fab?.visibility = View.GONE
        val sel = SelectorView(this) { rect -> finishSelect(rect) }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        selector = sel
        wm.addView(sel, p)
    }

    private fun finishSelect(rect: Rect?) {
        selector?.let { wm.removeView(it) }
        selector = null
        if (rect == null) {
            fab?.visibility = View.VISIBLE
            return
        }

        val l = rect.left.coerceIn(0, sw - 2)
        val t = rect.top.coerceIn(0, sh - 2)
        val r = rect.right.coerceIn(l + 2, sw)
        val b = rect.bottom.coerceIn(t + 2, sh)
        val cw = r - l
        val ch = b - t
        val scale = min(1f, MAX_SIDE / max(cw, ch))
        val ow = max(2, (cw * scale).toInt())
        val oh = max(2, (ch * scale).toInt())
        val box = Rect(l, t, r, b)

        toast("Recording. It stops by itself when the loop repeats, or tap STOP.")
        // let the screen redraw without our overlay, then start recording
        main.postDelayed({
            val st = Rec(l, t, cw, ch, ow, oh)
            showStop(box, st)
            bg.post {
                rec = st
                synchronized(lock) {
                    lastImage?.let {
                        try {
                            addFrame(it, st)
                        } catch (_: Throwable) {
                        }
                    }
                }
            }
            main.postDelayed({ bg.post { if (!st.movedAway) finish(st, Reason.STILL) } }, STILL_MS)
            main.postDelayed({ bg.post { finish(st, Reason.TIMEOUT) } }, MAX_MS)
        }, 350)
    }

    /** Background thread. Ends a recording once, whatever the reason, and saves the result. */
    private fun finish(st: Rec, reason: Reason) {
        synchronized(st) {
            if (st.done) return
            st.done = true
        }
        if (rec === st) rec = null
        main.post {
            removeStop()
            fab?.visibility = View.VISIBLE
        }

        val n = st.frames.size
        val still = st.firstFull
        if (reason == Reason.STILL || n < 2) {
            if (still != null) savePng(still) else toast("Nothing captured. Try again.")
            return
        }
        saveGif(st, reason)
    }

    private fun relativeDir() = Environment.DIRECTORY_PICTURES + "/StickerCollector"

    private fun savePng(bmp: Bitmap) {
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "sticker_${System.currentTimeMillis()}.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, relativeDir())
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
            if (uri == null) {
                toast("Could not create file")
                return
            }
            contentResolver.openOutputStream(uri)?.use {
                bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            toast("No movement found, saved a still image (PNG)")
        } catch (t: Throwable) {
            toast("Save failed: ${t.message}")
        }
    }

    private fun saveGif(st: Rec, reason: Reason) {
        val n = st.frames.size
        try {
            val avgGap = max(1L, (st.times.last() - st.times.first()) / (n - 1))
            val delays = ArrayList<Int>()
            for (i in 0 until n) {
                val gap = when {
                    i < n - 1 -> st.times[i + 1] - st.times[i]
                    st.endTime > 0 -> st.endTime - st.times[i]
                    else -> avgGap
                }
                delays.add(max(2, (gap / 10).toInt()))
            }
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "sticker_${System.currentTimeMillis()}.gif")
                put(MediaStore.Images.Media.MIME_TYPE, "image/gif")
                put(MediaStore.Images.Media.RELATIVE_PATH, relativeDir())
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
            if (uri == null) {
                toast("Could not create file")
                return
            }
            contentResolver.openOutputStream(uri)?.use { os ->
                GifEncoder.encode(st.frames, st.ow, st.oh, delays, os)
            }
            val why = when (reason) {
                Reason.LOOP -> "loop found"
                Reason.MANUAL -> "stopped by you"
                Reason.TIMEOUT -> "hit the ${MAX_MS / 1000}s limit, loop not detected"
                Reason.STILL -> "still"
            }
            toast("Saved clip ($why): $n frames, ${st.ow}x${st.oh}")
        } catch (t: Throwable) {
            toast("Save failed: ${t.message}")
        }
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() {
        rec = null
        fab?.let { runCatching { wm.removeView(it) } }
        selector?.let { runCatching { wm.removeView(it) } }
        removeStop()
        synchronized(lock) {
            lastImage?.close()
            lastImage = null
        }
        vd?.release()
        reader?.close()
        projection?.stop()
        bgThread.quitSafely()
        super.onDestroy()
    }
}
